A Pen created at CodePen.io. You can find this one at http://codepen.io/anthonydugois/pen/mewdyZ.

 Build SVG paths easily using this GUI.

The main goal was to provide a quick way to get a path, without having to open tools like Adobe Illustrator. Made in 1000 lines using React v0.14.